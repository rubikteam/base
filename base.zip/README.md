# PrestaShop Base Theme

The Base Theme is based on Prestashop 1.7 Base theme.
